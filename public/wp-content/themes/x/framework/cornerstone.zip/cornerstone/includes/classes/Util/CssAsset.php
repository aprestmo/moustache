<?php

namespace Themeco\Cornerstone\Util;

class CssAsset extends VersionedUrl {
  protected $ext = 'css';
}
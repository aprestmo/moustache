<?php

namespace Themeco\Cornerstone\Loopers\Providers;

class QueryMainWp extends QueryWp {

  public function begin() {
    // find the closest WP Query Provider
    // remember it
    // pause it
  }

  public function end() {
    // check if we stored the closest WP Query Provider
    // resume it
  }

}
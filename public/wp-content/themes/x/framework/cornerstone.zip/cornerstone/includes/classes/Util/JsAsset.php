<?php

namespace Themeco\Cornerstone\Util;

class JsAsset extends VersionedUrl {
  protected $ext = 'js';
}
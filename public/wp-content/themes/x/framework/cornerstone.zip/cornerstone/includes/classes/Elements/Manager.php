<?php

namespace Themeco\Cornerstone\Elements;

class Manager {



}
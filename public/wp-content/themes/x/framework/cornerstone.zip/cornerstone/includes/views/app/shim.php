<?php
  // Used by comment-form to prevent WordPress from outputting comments

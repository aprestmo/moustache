<?php

// @TODO support data
add_filter( 'cs_breakpoint_ranges', function($data) {
  return [ 480, 767, 979, 1200 ];
});

// Default range to match defaults
add_filter( 'cs_breakpoint_default_ranges', function($data) {
  return [ 480, 767, 979, 1200 ];
});


// Output theme styles
add_action( 'wp_enqueue_scripts', function() {

  if (!apply_filters("cs_use_standalone_theme_options", true)) {
    return;
  }

  $values = cornerstone("ThemeOptions")->getValues();

  $GLOBALS['__standalone_theme_values'] = $values[0];

  ob_start();

  include( __DIR__ . '/ThemeOptionsOutput.php');

  $css = ob_get_clean();

  cornerstone_register_styles('cs-standalone-generated', $css, -1000 );

}, 9998 );

<?php

namespace Themeco\Cornerstone\Loopers\Providers;

class Archive extends QueryMainWp {

}
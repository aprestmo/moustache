<?php

// The archive query passes through to the existing query in scope from WordPress

class Cornerstone_Looper_Provider_Archive extends Cornerstone_Looper_Provider_Wp_Query {

}
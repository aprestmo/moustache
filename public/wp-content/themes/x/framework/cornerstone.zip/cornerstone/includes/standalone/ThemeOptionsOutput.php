<?php

/**
 * Theme options output support for CS Standalone
 * See generated-css
 */

$values = $GLOBALS['__standalone_theme_values'];

$tags = [
  'root',
  'h1',
  'h2',
  'h3',
  'h4',
  'h5',
  'h6',
];

?>

/* <html>
// ========================================================================== */

/* <body>
// ========================================================================== */

:root {

<?php
try {
  foreach ($tags as $tag) {
    echo "--x-{$tag}-font-family: " . apply_filters('cs_css_post_process_font-family', $values[$tag . "_font_family"]);
    echo "--x-{$tag}-font-weight: " . apply_filters('cs_css_post_process_font-weight', $values[$tag . "_font_weight"]);
    echo "--x-{$tag}-font-style: " . $values[$tag . "_font_style"];
    echo "--x-{$tag}-letter-spacing: " . $values[$tag . "_letter_spacing"];
    echo "--x-{$tag}-line-height: " . $values[$tag . "_line_height"];
    //echo "--x-{$tag}-text-decoration: " . $values[$tag . "_text_decoration_style"];
    echo "--x-{$tag}-text-transform: " . $values[$tag . "_text_transform"];
    echo "--x-{$tag}-color: " . apply_filters('cs_css_post_process_color', $values[$tag . "_color"]);
  }
} catch (\Exception $e) {
  if (WP_DEBUG) {
    trigger_error("Could not create theme options output", E_USER_NOTICE);
  }
}

?>

}

/** Root **/
#cs-header, #cs-content, #cs-footer, .x-layout {
  font-family: var(--x-root-font-family);
  font-weight: var(--x-root-font-weight);
}


:where(#cs-header, #cs-content, #cs-footer, .x-layout) {
  /** Headings */
}

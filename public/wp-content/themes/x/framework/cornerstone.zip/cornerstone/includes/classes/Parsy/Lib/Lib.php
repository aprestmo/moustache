<?php

namespace Themeco\Cornerstone\Parsy\Lib;

class Lib {
  use Combinators;
  use Whitespace;
  use Symbols;
  use Terminators;
  use Macros;
  use Values;
}
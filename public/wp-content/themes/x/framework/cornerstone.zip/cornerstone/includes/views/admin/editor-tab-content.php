<div class="cs-editor-container">
  <div class="cs-editor-container-logo"><?php $this->view( csi18n('admin.editor-tab-logo-path') ); ?></div>
  <button data-cs-edit-button class="components-button is-primary button-primary">
    <span><?php e_csi18n('admin.edit-with-cornerstone'); ?></span>
  </button>
</div>

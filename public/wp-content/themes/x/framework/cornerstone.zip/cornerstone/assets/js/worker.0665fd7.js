(()=>{onmessage=function(e){};})();
